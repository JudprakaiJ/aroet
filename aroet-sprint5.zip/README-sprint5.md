# AROET Sprint 5 — Fix 11 + Cleanup

## What changed

### /cases/new — Cleanup + Title field
- ❌ **REMOVED** Planner Note section (Planner workflow ออกจาก single source of truth)
- ❌ **REMOVED** "Auto-parse sessions" checkbox
- ✅ **ADDED** Title field (required, 1 line — copy from D365 case title)
- ✅ **CHANGED** Description: now optional, 2 rows (used for additional context only)
- ✅ **ADDED** SO format validation: must match `SO\d{4}-\d{1,3}` (e.g. SO2605-21)
- ✅ **ADDED** SR format validation: must match `SR\d{2}-AROET\d+` (e.g. SR26-AROET03450)
- ✅ **ADDED** Title required check
- ✅ **ADDED** Customer required check
- ✅ **ADDED** At least 1 machine required check
- ✅ **ADDED** Lead engineer required check
- ✅ Better error messages

### Schema cleanup (optional)
- `sql/08_sessions_nullable_so.sql` — drops NOT NULL on sessions.so_number
  - Enables saving AL/SICK/PERS leave sessions without a case in /planning
  - **Run this SQL if you got "null value violates not-null" errors when assigning leave types**

## Files
src/app/cases/new/form.tsx              (removed planner section, added title field, added validation)
src/app/cases/new/actions.ts            (NewCaseInput updated: +title, -planner_note, -auto_parse_sessions)
sql/08_sessions_nullable_so.sql         NEW (optional schema cleanup)

## Deploy

### 1. Apply code
```bash
cd /workspaces/aroet
# Upload aroet-sprint5.zip
cd /tmp && rm -rf sprint5
unzip -o /workspaces/aroet/aroet-sprint5.zip -d sprint5

cd /workspaces/aroet
cp -r /tmp/sprint5/src/* src/
cp /tmp/sprint5/sql/08_sessions_nullable_so.sql sql/
rm -rf /tmp/sprint5

git add -A
git commit -m "Sprint 5: Fix 11 - remove Planner Note + add Title field + validation"
git push
```

### 2. (Optional) Run SQL to allow leave session saves
Only run if you got NOT NULL errors with AL/SICK in /planning:
```sql
alter table sessions alter column so_number drop not null;
```

## Test flow

1. Go to /cases/new
2. Verify NO Planner Note section anywhere
3. Verify NEW Title field is present (after Service Type, before Description)
4. Try submitting with empty title → should error "Title required"
5. Try SO "ABC" → should error "SO format should be like..."
6. Try SR "ABC" → should error "SR format should be like..."
7. Fill everything correctly → case created successfully
8. Check /cases/[so] — title shows the value you typed (not auto-built)

## Known notes
- Old cases (created before Sprint 5) keep their auto-generated titles — they still work fine
- `planner_note` column still exists in DB and shows in /cases/[so] Planner tab (read-only)
  - Future: can drop the column if no longer needed via separate migration

## Next priorities
- Sprint 6: AROET login + permissions
- Sprint 7: Service Report DOCX generation
- Sprint 8: PM checklist UI / Pay calculation
