# AROET Fix 12 — Cleanup batch

## 4 bugs fixed

### Bug 1: Dashboard hardcode "All 883 cases"
**Before**: hardcoded count "883" — wrong after DB reset
**After**: query DB for real count via `supabase.from("cases").select("*", { count: "exact", head: true })`

### Bug 2: Dashboard "From planner note" copy
**Before**: "Create case — From planner note" — outdated
**After**: "Create case — SO + customer + machines" — matches new workflow

### Bug 3: /cases "⚡ Bulk parse" button
**Before**: Button linked to /admin/bulk-reparse (Planner workflow)
**After**: Button removed — no longer needed (AROET = single source of truth)

### Bug 4: Service codes wrong vs Excel team data
**Before** (wrong codes):
- 7510 Installation
- 7520 Upgrade
- 7525 Training
- 7235 Voucher

**After** (matches Excel actual data):
- 7504 Installation
- 7505 Curative
- 7506 Upgrade variant
- 7507 PM
- 7508 Upgrade
- 7510 Customer Training
- 7511 Internal Training
- 7512 Service Agreement
- 7515 Curative under Warranty
- 7530 Promotion

Both form dropdown + SERVICE_TYPE_NAMES map updated.

## Files
src/app/page.tsx                        (added totalCases query, fixed 2 copy strings)
src/app/cases/page.tsx                  (removed Bulk parse button)
src/app/cases/new/form.tsx              (fixed service type options)
src/app/cases/new/actions.ts            (fixed SERVICE_TYPE_NAMES)

## Deploy

```bash
cd /workspaces/aroet
# Upload aroet-fix12.zip
cd /tmp && rm -rf fix12
unzip -o /workspaces/aroet/aroet-fix12.zip -d fix12

cd /workspaces/aroet
cp -r /tmp/fix12/src/* src/
rm -rf /tmp/fix12

git add -A
git commit -m "Fix 12: dashboard counts, service codes, remove bulk-parse"
git push
```

## Test
1. Dashboard /  →  Quick Actions แสดง count จริง (ไม่ใช่ 883)
2. Dashboard / → "Create case · SO + customer + machines"
3. /cases → ไม่มีปุ่ม "⚡ Bulk parse"
4. /cases/new → Service type dropdown มี 9 options ที่ถูกต้อง

## No SQL changes
Code-only fixes.
