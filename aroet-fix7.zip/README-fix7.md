# AROET Fix 7 — UI Redesign (Sprint 1)

## What changed
Comprehensive UI redesign applying consistent design tokens across all pages:
- Font scale: html 15px base, h1 28px, h2 17px, stats 28-32px, body 13-14px
- Spacing: card padding 20px, page gutter 24px (px-6 py-8), section gap 20px
- Border radius: rounded-2xl for cards, rounded-lg for buttons
- Activity colors as CSS vars (Field=#185FA5, Travel=#993556, Office=#5F5E5A, etc.)
- Status badges sized + colored consistently
- Card hover lift via .card-hover utility

## Pages redesigned
- `/` — Dashboard with greeting, 4 stat cards, upcoming cases list, quick actions panel
- `/cases` — Big case cards (16px SO, 15px title), lead engineer ⭐, project code chip extracted from title, status badges, overdue red border
- `/cases/[so]` — Bigger header (24px SO mono), 28px stat values, removed green banner, ⭐ lead badge in Engineers tab
- `/workforce` — 28px h1, segment buttons for periods, 32px stats, table cells 28px height (was 18px), avatars 36px, ΣT/ΣC/ΣAR with activity colors, Submit button red
- `/customers` — Bigger headers, cleaner table rows
- `/machines` — Filter chips, bigger version badges
- `/engineers` — Bigger code badges, colored Travel/Work columns
- `/planning` — Card-style group headers with color bar, urgency subtitles

## Files changed
src/app/globals.css                        # design tokens
src/components/top-nav.tsx                 # bigger nav + Dashboard link
src/app/page.tsx                           # new Dashboard
src/app/cases/page.tsx                     # big cards
src/app/cases/[so_number]/page.tsx         # clean header, no banner
src/app/workforce/calendar.tsx             # all sizing upgraded
src/app/customers/page.tsx                 # design tokens
src/app/machines/page.tsx                  # design tokens
src/app/engineers/page.tsx                 # design tokens
src/app/planning/page.tsx                  # design tokens

## Deploy
```bash
cd /workspaces/aroet
# Upload aroet-fix7.zip into workspace
cd /tmp && rm -rf fix7
unzip -o /workspaces/aroet/aroet-fix7.zip -d fix7

cd /workspaces/aroet
cp -r /tmp/fix7/src/* src/
rm -rf /tmp/fix7

git add -A
git commit -m "Fix 7: UI redesign (Sprint 1) — consistent design tokens across all pages"
git push
```

After Vercel deploys (~2 min), expect:
- Dashboard: greeting + 4 stat cards + upcoming + quick actions
- All pages: bigger fonts, more whitespace, easier to read
- Workforce: bigger calendar cells, clearer ΣT/ΣC/ΣAR
- Cases: lead engineer ⭐, project code chips

## Notes
- `project_code` is extracted from case title via regex (e.g., "ZEGU99 - G7 Maintenance" → ZEGU99)
- Lead engineer star comes from `case_engineers.is_lead = true`
- If no case_engineers rows exist for a case, no avatars shown
- All design tokens are CSS variables in globals.css — easy to tweak later
