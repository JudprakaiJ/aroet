# AROET Fix 10 — Detail pages with Edit + Delete

## What's new

### `/customers/[code]` (NEW)
- Header card: legal name + code + Edit/Delete buttons
- Info grid: address, country, notes
- **Contacts section** with Add/Edit/Delete per contact
- Tabs: **Machines** and **Cases** of this customer
- Click row in /customers list → opens this page

### `/machines/[machine_no]` (UPGRADED)
- Bigger header (24px mono machine_no) with Edit/Delete
- Info grid: product, serial, install date, warranty
- Notes section
- 3 stats: total cases, PM, Curative
- Service history table (last 30 cases)
- Linked customer is clickable to customer detail

### Edit pattern
All edits use **modal popups** (matches Create pattern).

### Delete pattern
2-step confirmation:
1. Warning modal (Continue button)
2. Type the code/machine_no exactly to confirm

Deletion is blocked if entity has cases/case_machines referencing it.

## Files
src/app/customers/actions.ts                     (added updateCustomer, updateContact, deleteCustomer, addContactToCustomer, deleteContact)
src/app/customers/client.tsx                     (rows now link to detail page)
src/app/customers/[code]/page.tsx                NEW (server)
src/app/customers/[code]/client.tsx              NEW (UI + modals)
src/app/machines/actions.ts                      (added deleteMachine, kept updateMachine)
src/app/machines/[machine_no]/page.tsx           (rewritten with design tokens)
src/app/machines/[machine_no]/client.tsx         NEW (UI + modals)

## No DB changes — code only

## Deploy
```bash
cd /workspaces/aroet
# Upload aroet-fix10.zip
cd /tmp && rm -rf fix10
unzip -o /workspaces/aroet/aroet-fix10.zip -d fix10

cd /workspaces/aroet
cp -r /tmp/fix10/src/* src/
rm -rf /tmp/fix10

# Remove stale file from earlier fix if still present
rm -f src/app/customers/list-client.tsx

git add -A
git commit -m "Fix 10: Customer + Machine detail pages with Edit and Delete"
git push
```

## Test flow

### Customer detail
1. /customers → click any row → /customers/[code]
2. See header with Edit/Delete
3. Click ✎ Edit → modal opens with current values → change → Save → page refreshes
4. Click + Add contact → modal → fill → Save → appears in list
5. Click ✎ on a contact → edit modal
6. Click 🗑 on a contact → inline confirm → delete
7. Click Machines tab → see linked machines
8. Click Cases tab → see linked cases
9. Click 🗑 Delete (header) → 2-step confirm → must type code → delete

### Machine detail
1. /machines → click any row → /machines/[machine_no]
2. Same edit/delete flow
3. Service history table at bottom
