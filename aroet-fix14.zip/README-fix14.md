# AROET Fix 14 — Merge Workforce + Planning + Queue → 1 page with 3 tabs

## Nav before vs after

**Before** — 8 links:
```
Dashboard | Cases | Workforce | Queue | Customers | Machines | Planning | Team
```

**After** — 6 links:
```
Dashboard | Cases | Workforce | Customers | Machines | Team
```

Workforce now has 3 tabs internally:
- 📋 **Plan** — grid view (was /planning)
- ⏱️ **Hours** — calendar heat map (was /workforce)
- ✅ **Queue** — approval queue with red badge (was /workforce/queue)

## URL structure

```
/workforce              → Plan tab (default)
/workforce?tab=plan     → Plan
/workforce?tab=hours    → Hours
/workforce?tab=queue    → Queue

Legacy URLs still work (redirect):
/planning               → /workforce?tab=plan
/workforce/queue        → /workforce?tab=queue
```

## Features

### Tab bar (top of workforce page)
- Sticky-feeling tab strip
- Active tab highlighted with white background + bottom border
- Queue tab shows red badge with pending count
- All search params preserved within each tab

### Plan tab
- Same Excel-style grid as before
- Click cell to assign session
- 4/8/12 weeks selector
- All assignSession / clearDay actions still work

### Hours tab
- Same calendar heat map as before
- Pay period selectors (1-20 / 21-end / custom)
- OT detection
- All existing logic preserved

### Queue tab
- Same approval queue as before
- Bulk approve checkboxes
- Filter by engineer
- Return modal with reason
- Overlap detection

### Pending count badge
- Shared across all 3 tabs
- Updates on each render
- Also appears on Dashboard "Pending approval" stat card → links to Queue tab

## Files

### NEW
src/app/workforce/page.tsx              (dispatcher — picks tab from search params)
src/app/workforce/tabs.tsx              (shared tab navigation)
src/app/workforce/plan-view.tsx         (Plan tab component)
src/app/workforce/hours-view.tsx        (Hours tab component, was page.tsx)
src/app/workforce/queue-view.tsx        (Queue tab component)

### REDIRECTS (kept for backwards compat)
src/app/planning/page.tsx               (redirect → /workforce?tab=plan)
src/app/workforce/queue/page.tsx        (redirect → /workforce?tab=queue)

### MODIFIED
src/components/top-nav.tsx              (removed Queue + Planning links)
src/app/page.tsx                        (Pending approval → /workforce?tab=queue; added query)

### UNCHANGED (still used as components by views)
src/app/workforce/calendar.tsx
src/app/workforce/actions.ts
src/app/workforce/queue/client.tsx
src/app/workforce/queue/actions.ts
src/app/workforce/queue/lib.ts
src/app/planning/grid.tsx
src/app/planning/actions.ts

## Deploy (no SQL)

```bash
cd /workspaces/aroet
# Upload aroet-fix14.zip
cd /tmp && rm -rf fix14
unzip -o /workspaces/aroet/aroet-fix14.zip -d fix14

cd /workspaces/aroet
cp -r /tmp/fix14/src/* src/
rm -rf /tmp/fix14

git add -A
git commit -m "Fix 14: merge Workforce + Planning + Queue into tabs"
git push
```

## Test flow

1. Top nav shows 6 links (Queue + Planning removed)
2. Click "Workforce" → lands on Plan tab (default)
3. Click "Plan" / "Hours" / "Queue" tabs at top
4. Pending count appears as red badge on Queue tab
5. Dashboard "Pending approval" card → links to /workforce?tab=queue
6. Old URL /planning → redirects to /workforce?tab=plan
7. Old URL /workforce/queue → redirects to /workforce?tab=queue

## Known
- Each tab loads fresh data on switch (no shared state) — fast on small DBs
- Pendingcount query runs on every workforce render (small overhead but fresh data)
