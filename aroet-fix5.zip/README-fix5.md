# AROET Fix 5 — Parser smart-3-blocks + ABC breakdown UI

## Parser fix
**Problem:** PSU 02/05 case showed C=8h30' instead of 6h00'.
Raw: `7:30-08:00 (30') 14:30-15:00 17:00-23:15(TH) C=6h T=8h15`
3 time blocks (1=hotel→site, 2=site→hotel, 3=flight back) — parser computed work = on-site duration which was wrong.

**Fix:** Smart compute logic:
- 1 block → travel-only day
- 2 blocks → standard out+back → compute work from on-site duration
- 3+ blocks → complex schedule → trust planner C= and T= values

Tests pass:
✅ PSU 02/05 (3 blocks): T=8h15 C=6h (from planner) — was T=8h15 C=8h30 (computed)
✅ RKO 31/03 (2 blocks): T=1h15 C=7h45 (computed) — unchanged
✅ Travel-only (1 block): T=8h C=0 — unchanged

## UI fix — ABC breakdown
**Top engineer row:** added ΣT, ΣC, ΣAR columns (colored: travel=pink, work=blue, office=gray)
**Expand case row:** added same 3 columns showing case-level T/C/AR sums
**Sub-rows under each case (NEW):**
  - T= Travel — shows travel minutes per day (e.g. "1h15" or "2h")
  - C= Work — shows work minutes per day
  - AR= Office — shows office minutes per day (only when AR= present)

Sub-rows hidden when their value is 0.

## Files changed
src/lib/planner/parser.ts          (FIX D logic for 2 vs 3+ blocks)
src/app/workforce/calendar.tsx     (ABC columns + sub-rows under each case)

## Deploy
```bash
cd /workspaces/aroet
# Upload aroet-fix5.zip
cd /tmp && rm -rf fix5 && unzip -o /workspaces/aroet/aroet-fix5.zip -d fix5
cd /workspaces/aroet
cp -r /tmp/fix5/src/* src/
rm -rf /tmp/fix5
git add -A
git commit -m "Fix 5: parser 3+blocks + workforce ABC breakdown"
git push
```

## After deploy
1. Wait Vercel rebuild (~2 min)
2. Go to /admin/bulk-reparse → run again to fix PSU 02/05 case data
3. /workforce should show:
   - Engineer row: ΣT | ΣC | ΣAR | Σ | OT | Status (6 right columns)
   - Click ▸ → see SO row + Travel sub-row + Work sub-row (+ Office if AR>0)
