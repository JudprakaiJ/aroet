# AROET Fix 3 — Bulk re-parse timeout fix

## Problem
- `/admin/bulk-reparse` timed out after 5 minutes (Vercel limit)
- Original: 883 cases × ~6 DB calls each = ~6000 queries, ~20 min runtime
- Also: build failed on Vercel because pages tried to pre-render and hit Supabase without env vars

## Fix
1. **Batch processing** — split into 25-case batches, each batch <10s
2. **Client-side loop** — JS calls `bulkReparseBatch(cursor)` repeatedly with progress bar
3. **Bulk operations** — `delete().in(soList)` once per batch instead of 3 queries per case
4. **Stop button** — user can interrupt anytime
5. **Force dynamic** — `export const dynamic = "force-dynamic"` on all data-loading pages
   so Vercel doesn't try to pre-render them at build time

## Files changed
```
src/app/admin/bulk-reparse/
  ├── page.tsx       # +force-dynamic
  ├── actions.ts     # NEW: bulkReparseBatch(cursor, opts) + legacy bulkReparse
  └── form.tsx       # NEW: client-side loop with progress + stop button

src/app/cases/page.tsx          # +force-dynamic
src/app/cases/[so_number]/page.tsx
src/app/cases/new/page.tsx
src/app/customers/page.tsx
src/app/engineers/page.tsx
src/app/machines/page.tsx
src/app/machines/[machine_no]/page.tsx
src/app/planning/page.tsx
src/app/page.tsx
```

## Deploy

```bash
cd /workspaces/aroet

# 1. Upload aroet-fix3.zip into /workspaces/aroet/
# 2. Apply
cd /tmp && rm -rf fix3 && unzip -o /workspaces/aroet/aroet-fix3.zip
ls /tmp/fix3/src/app/admin/bulk-reparse/  # verify

cd /workspaces/aroet
cp -r /tmp/fix3/src/* src/
rm -rf /tmp/fix3

# 3. Commit + push
git add -A
git commit -m "Fix 3: batch bulk-reparse + force-dynamic pages"
git push
```

## Expected behavior after fix
- `/admin/bulk-reparse` shows progress bar live: 25/883 → 50/883 → ... → 883/883
- Each batch takes ~3-5s
- Total ~3-4 minutes for 883 cases (still long but visible)
- No more 504 timeout
