# AROET Fix 6A — Shared session detection

## Problem
Engineers copy-paste the same raw line into multiple SOs' planner_notes when
they worked multiple cases in parallel on the same day. Example:
- SO2505-04 and SO2505-05 both contain: `15/12/2025: RKO, TCH, PSU: 08:30-10:30(30') 19:00-19:30 C=8h00' T=2h30'`

This caused hours to be double-counted in workforce calendar:
- PSU 15/12: showed 16h (actual 8h)
- 5 cases × 12h44m one day for TCH/SPE 2025-03-06 = 62 hours!

## Fix
1. **DB schema** (sql/04_shared_sessions.sql)
   - Add `sessions.is_shared` (bool)
   - Add `sessions.shared_with_so` (text[])
   - Index for fast duplicate detection

2. **Parser (bulk-reparse actions.ts)**
   - When batch contains 2+ SOs with identical (engineer + date + raw_line):
     - Flag all of them `is_shared = true`
     - Each row knows which OTHER SOs it's shared with
   - Also looks at existing DB rows (cross-batch sharing)

3. **Workforce deduplication (workforce/calendar.tsx)**
   - Sessions are deduped by signature (engineer + date + minutes + activity)
   - Total hours / OT / engineer presence — count canonical session once
   - Cases worked counter — counts ALL SOs (shared SOs included)

## Files
sql/04_shared_sessions.sql                          # Run in Supabase first
src/app/workforce/page.tsx                          # Adds is_shared cols to query
src/app/workforce/calendar.tsx                      # Dedup logic
src/app/admin/bulk-reparse/actions.ts               # Detect + flag shared

## Deploy
```bash
# 1. Run SQL in Supabase: sql/04_shared_sessions.sql
# 2. Upload aroet-fix6a.zip to Codespace
cd /workspaces/aroet
cd /tmp && rm -rf fix6a && unzip -o /workspaces/aroet/aroet-fix6a.zip -d fix6a
cd /workspaces/aroet
cp -r /tmp/fix6a/src/* src/
cp /tmp/fix6a/sql/04_shared_sessions.sql sql/
rm -rf /tmp/fix6a

git add -A
git commit -m "Fix 6A: shared session detection + workforce dedup"
git push

# 3. After Vercel deploys (~2min):
#    Visit /admin/bulk-reparse → Run "All cases" → wait ~3min
#    This re-parses all 883 cases with new shared-detection logic.
# 4. Check /workforce: PSU 15/12 should now show 8h (not 16h)
```

## Verify
After bulk reparse, run in Supabase:
```sql
SELECT engineer_code, session_date, count(*) as rows,
       sum(travel_minutes + work_minutes + office_minutes) as total_min_raw,
       count(distinct concat(travel_minutes, work_minutes, office_minutes)) as unique_minute_combos
FROM sessions
WHERE source = 'planner' AND is_shared = true
GROUP BY engineer_code, session_date
ORDER BY rows DESC LIMIT 10;
```
