# AROET Fix 8B — Remove machines.is_active references

## Problem
DB doesn't have `machines.is_active` column. Pages crashed.

## Fix
- Removed `.eq("is_active", true)` filter from 3 places
- Removed `is_active: true` from machine inline-create

## Files
src/app/machines/page.tsx
src/app/cases/new/page.tsx
src/app/cases/new/actions.ts

## Deploy
```bash
cd /workspaces/aroet
unzip -o /workspaces/aroet/aroet-fix8b.zip -d /tmp/fix8b
cp -r /tmp/fix8b/src/* src/
rm -rf /tmp/fix8b
git add -A && git commit -m "Fix 8B: remove machines.is_active references" && git push
```
