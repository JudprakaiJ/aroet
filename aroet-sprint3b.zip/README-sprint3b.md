# AROET Sprint 3B — Fix server actions error

## Problem
`detectOverlaps` was exported from `actions.ts` which has `"use server"` directive.
Next.js requires ALL exports from server-action files to be async functions.

## Fix
- Moved `detectOverlaps` (sync utility) to new `lib.ts` file
- Updated `client.tsx` to import from `./lib` instead of `./actions`
- `actions.ts` now only has async server actions

## Files
src/app/workforce/queue/lib.ts        NEW (overlap detection utility)
src/app/workforce/queue/actions.ts    (removed detectOverlaps)
src/app/workforce/queue/client.tsx    (updated import path)

## Deploy
```bash
cd /workspaces/aroet
# Upload aroet-sprint3b.zip
cd /tmp && rm -rf sprint3b
unzip -o /workspaces/aroet/aroet-sprint3b.zip -d sprint3b

cd /workspaces/aroet
cp -r /tmp/sprint3b/src/* src/
rm -rf /tmp/sprint3b

git add -A
git commit -m "Sprint 3B: fix server actions export (move detectOverlaps to lib)"
git push
```
