# AROET Sprint 3 — Approval Queue + Inline Add Session

## What's new

### 1. `/workforce/queue` (NEW page)
Approval queue for admins to review submitted sessions.
- Table of sessions waiting for approval (default view)
- Toggle: Submitted | Approved (with this-month filter)
- Engineer filter chips (with counts)
- Bulk approve via checkboxes + "Approve selected" button
- Quick action buttons per row: ✓ Approve, ↺ Return
- Return modal asks for reason
- **Overlap detection**: highlights rows where engineer's day total > 16h
- Daily activity color chips (Field/Travel/Office/etc.)

### 2. Inline "+ Add session" on `/cases/[so]` Sessions tab
- Toggle button → expands inline form (not modal)
- Fields:
  - Date (default today)
  - Engineer (default = lead, dropdown of active engineers)
  - Activity chip buttons (Field/Travel/Remote/Training/Upgrade/Office)
  - Start time / End time / Break minutes / **Auto-calc Duration**
  - Machine (dropdown from case_machines, ⭐ primary marked)
  - Notes (optional)
  - ☑ Checkbox: "Submit for approval immediately"
- Activity → maps to travel/work/office minutes automatically:
  - "travel" → travel_minutes
  - "office" → office_minutes
  - field/remote/training/upgrade → work_minutes

### 3. Sessions tab redesigned
- Group by date with daily totals (Travel/Work/Office breakdown)
- Color-coded activity chips
- Add session button at top right

### 4. Top nav: + Queue link
Between "Workforce" and "Customers"

## Schema notes
**NO SQL changes needed** — uses existing schema:
- `sessions.approval_status`: 'draft' | 'submitted' | 'returned' | 'approved'
- `session_approval_log` for audit trail

If `approved_at` column is missing on sessions, the approve action will log a warning but still update status — non-blocking.

## Files added
src/app/workforce/queue/page.tsx              NEW (server)
src/app/workforce/queue/client.tsx            NEW (UI)
src/app/workforce/queue/actions.ts            NEW (approve/return/bulk)
src/app/cases/[so_number]/add-session.tsx     NEW (inline form)
src/app/cases/[so_number]/session-actions.ts  NEW (addSession/updateSession/deleteSession)

## Files modified
src/app/cases/[so_number]/page.tsx            (added engineers + machines fetch, new SessionsTab with Add button)
src/components/top-nav.tsx                    (added Queue link)

## Deploy

```bash
cd /workspaces/aroet
# Upload aroet-sprint3.zip
cd /tmp && rm -rf sprint3
unzip -o /workspaces/aroet/aroet-sprint3.zip -d sprint3

cd /workspaces/aroet
cp -r /tmp/sprint3/src/* src/
rm -rf /tmp/sprint3

git add -A
git commit -m "Sprint 3: Approval queue + inline Add Session form"
git push
```

## Test flow

### Add a session
1. Go to /cases/[any SO]
2. Sessions tab → click "+ Add session"
3. Inline form expands
4. Pick date, engineer, activity, time
5. Check "Submit immediately" if you want
6. Click "Save session"
7. New session appears in list with status badge

### Approve sessions
1. Have at least 1 session with status = "submitted"
2. Go to /workforce/queue (nav link)
3. See pending submissions
4. Filter by engineer if needed
5. Approve individually (✓) or check multiple + bulk approve
6. Or return with reason (↺)

### Overlap detection
If same engineer has > 16h on same date → row highlights red with "⚠ Possible overlap" badge

## Known notes
- ⚠ If your DB schema lacks `sessions.approved_at` column, the `approveSession` action will fail silently on that field — sessions still get `approval_status = approved`. Add the column if you want timestamps:
  ```sql
  alter table sessions add column if not exists approved_at timestamptz;
  ```
- Sessions parsed from Planner Note still default to `approval_status = draft`
- Approved sessions cannot be deleted (locked)
