# AROET Fix 13 — Title parser + correct Service Types

## What's new

### 1. Title-paste auto-parser (top of /cases/new)
- New section **at the top** of new-case form
- Paste D365 case title → auto-parses 4 fields:
  - SO Number
  - Project code
  - Machine code (hint — user adds machine via search below)
  - Subject (Title for AROET)
- Debounce 500ms while typing
- Shows "Detected" preview with red highlighted values
- Click "↓ Auto-fill empty fields" to apply to form

### 2. Parser logic (src/lib/title-parser.ts)
- Pattern detection priority:
  - SO: `SO\d{4}-\d{1,3}` (e.g. SO2604-05)
  - Machine: RE\d+, AR\d+SV\d+, Line#\d+, Group\s\d+, MCE#\d+, MCVP/SPF/SPV/PE/DLM/TLS variants
  - Project: 3-7 uppercase letters + 2-3 digits (e.g. ESRY13, ROTH99, ESFOC98)
  - Subject: everything else, with PO/SQ/CS stripped
- Strips noise: 10-digit PO numbers, (SQxxx-xx), CSxxxxx, ELN26-xxxx-x

### 3. Service Types FIXED — now match D365 exactly
Based on actual 883 cases in D365:

| Code | Name | Count |
|------|------|-------|
| 7505 | Curative maintenance | 241 |
| 7504 | Installation | 192 |
| 7515 | Curative maintenance under Warranty | 171 |
| 7508 | Upgrade installation | 86 |
| 7507 | Preventive Maintenance | 79 |
| 7512 | Service Agreement | 65 |
| 7235 | Service Promotion | 34 |
| 7506 | Customer Training | 5 |
| 7506-1 | Internal Training | 3 |

Previous codes that were WRONG (now removed):
- ~~7510 Customer Training~~ → 7506
- ~~7511 Internal Training~~ → 7506-1
- ~~7530 Promotion~~ → 7235

## Test scenarios (parser handles all 6 sample titles correctly)

| Input | SO | Project | Machine | Subject |
|---|---|---|---|---|
| `SO2604-05 - ESRY13 - Line#15 - Installation and Training Automapper + SPV-3 - 4553487864 (SQ2604-08)` | SO2604-05 | ESRY13 | Line#15 | Installation and Training Automapper + SPV-3 |
| `SO2605-01 CS29459 - RE55 - ESSA05 - request support upgrade Barcode Reader MCE#07 - ELN26-0367-0 (SQ2604-20)` | SO2605-01 | ESSA05 | RE55 | request support upgrade Barcode Reader MCE#07 |
| `SO2603-26 - AR25SV484 - ESFOC98 - SPV3 SN: AR25SV484 Freezing` | SO2603-26 | ESFOC98 | AR25SV484 | SPV3 SN: AR25SV484 Freezing |
| `SO2602-19 - Group 1 - ROTH99 - Preventive maintenance 2026 - 4500092637 (SQ2602-04)` | SO2602-19 | ROTH99 | Group 1 | Preventive maintenance 2026 |
| `SO2602-08 - RE72 - ESSA01 - TLS issue - (SQ2602-21 SQ2602-23)` | SO2602-08 | ESSA01 | RE72 | TLS issue |

## Files
src/lib/title-parser.ts                 NEW
src/app/cases/new/form.tsx              (added title-paste section, parser hook, ParsedField helper)
src/app/cases/new/actions.ts            (SERVICE_TYPE_NAMES updated to D365 actuals)

## Deploy (no SQL)

```bash
cd /workspaces/aroet
# Upload aroet-fix13.zip
cd /tmp && rm -rf fix13
unzip -o /workspaces/aroet/aroet-fix13.zip -d fix13

cd /workspaces/aroet
mkdir -p src/lib
cp -r /tmp/fix13/src/* src/
rm -rf /tmp/fix13

git add -A
git commit -m "Fix 13: D365 title parser + correct service types"
git push
```

## Test flow
1. Go to /cases/new
2. See NEW "✨ Paste D365 title" section at the top
3. Paste: `SO2604-05 - ESRY13 - Line#15 - Installation and Training Automapper + SPV-3`
4. Wait 500ms — "Detected" panel appears with:
   - SO Number: SO2604-05
   - Project: ESRY13
   - Machine: Line#15
   - Title: Installation and Training Automapper + SPV-3
5. Click "↓ Auto-fill empty fields"
6. SO Number / Project code / Title all populate automatically
7. Verify Service Type dropdown shows 9 correct codes including 7235 Service Promotion
