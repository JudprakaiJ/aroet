# AROET Fix 9 — Add Customer + Machine standalone

## What's new
1. **+ New customer** button on `/customers` page
   - Modal with full fields: legal name, code (auto-gen), city, country, address, notes
   - Multiple contacts: name, role, phone, email, ⭐ primary
   - Add/remove contacts inline
   
2. **+ New machine** button on `/machines` page
   - Modal with: machine_no, customer (search), name, product code, serial, version, install date, warranty, notes
   
3. **Customer detail expand** — click row in /customers to expand
   - Shows address, notes
   - List of all contacts with primary star

## Schema changes (sql/06)
- `customer_contacts` junction table (id, customer_code, name, role, phone, email, is_primary, notes)
- `customers.address`, `customers.notes` columns added
- `machines.warranty_expiry`, `installation_date`, `notes` columns added

## Files
sql/06_contacts_and_machine_fields.sql       ← run in Supabase first
src/app/customers/page.tsx                    (server)
src/app/customers/client.tsx                  (UI + modal)
src/app/customers/actions.ts                  (createCustomer, addContact, deleteContact)
src/app/machines/page.tsx                     (server)
src/app/machines/client.tsx                   (UI + modal)
src/app/machines/actions.ts                   (createMachine, updateMachine)

## Deploy

### 1. Run SQL migration first
Paste `sql/06_contacts_and_machine_fields.sql` into Supabase SQL Editor → Run.
Verify section should show all 4 columns confirmed.

### 2. Apply code
```bash
cd /workspaces/aroet
# Upload aroet-fix9.zip
cd /tmp && rm -rf fix9
unzip -o /workspaces/aroet/aroet-fix9.zip -d fix9

cd /workspaces/aroet
cp -r /tmp/fix9/src/* src/
cp /tmp/fix9/sql/06_contacts_and_machine_fields.sql sql/
rm -rf /tmp/fix9

git add -A
git commit -m "Fix 9: standalone Add Customer + Add Machine modals with contacts"
git push
```

## Test flow

### Add customer with multiple contacts:
1. Go to `/customers`
2. Click **+ New customer**
3. Fill: legal name "Essilor Test Co.", city Bangkok, country Thailand
4. Add 2 contacts:
   - Contact 1: ⭐ Khun Somchai, Technical Manager, +66-89-123, somchai@example.com
   - Click + Add contact → Khun Suda, Procurement, +66-89-456, suda@example.com
5. Click Create customer → row appears in list
6. Click row to expand → see contacts list

### Add machine:
1. Go to `/machines`
2. Click **+ New machine**
3. Fill: machine_no "MCVP4-200", search customer "Essilor", name, product code...
4. Click Create machine → row appears

## Notes
- Customer code auto-generates if blank (4 letters + 2-digit suffix)
- Primary contact gets denormalized to `customers.contact_name` for backwards compat
- Machine inline-create from /cases/new still works (uses same actions)
