-- =============================================================================
-- AROET Sprint 2.5 — Customer contacts + machine extra fields
-- Run in Supabase SQL Editor
-- =============================================================================

-- 1. Add address to customers (legal name + city/country exist)
alter table customers add column if not exists address text;
alter table customers add column if not exists notes text;

-- 2. Customer contacts (junction table: 1 customer -> many contacts)
create table if not exists customer_contacts (
  id              bigserial primary key,
  customer_code   text not null references customers(code) on delete cascade,
  name            text not null,
  role            text,
  phone           text,
  email           text,
  is_primary      boolean default false,
  notes           text,
  created_at      timestamptz default now()
);

create index if not exists idx_customer_contacts_code on customer_contacts (customer_code);
create index if not exists idx_customer_contacts_primary on customer_contacts (customer_code, is_primary);

-- 3. Add full set of machine extra fields
alter table machines add column if not exists warranty_expiry date;
alter table machines add column if not exists installation_date date;
alter table machines add column if not exists notes text;

-- 4. Grants
grant select, insert, update, delete on customer_contacts to anon, authenticated;
grant usage, select on sequence customer_contacts_id_seq to anon, authenticated;
alter table customer_contacts disable row level security;

-- 5. Verify
select
  (select count(*) from information_schema.columns
    where table_name='customers' and column_name='address') as customer_has_address,
  (select count(*) from information_schema.columns
    where table_name='customers' and column_name='notes') as customer_has_notes,
  (select count(*) from information_schema.columns
    where table_name='machines' and column_name='warranty_expiry') as machine_has_warranty,
  (select count(*) from information_schema.columns
    where table_name='machines' and column_name='installation_date') as machine_has_install_date,
  (select count(*) from information_schema.columns
    where table_name='machines' and column_name='notes') as machine_has_notes,
  (select count(*) from information_schema.tables
    where table_name='customer_contacts') as contacts_table_exists;
