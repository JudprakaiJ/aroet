# AROET Fix 7B — Remove project_code column reference

## Problem
`/cases` page broke with "column cases.project_code does not exist"

## Root cause
Fix 7's cases query included `project_code` in SELECT. The plan was to extract
project codes from `title` via regex — but I left the column reference in by
mistake. DB doesn't have that column.

## Fix
- Removed `project_code` from SELECT list
- `extractProjectCode(c.title)` regex still works as designed (extracts e.g.
  "ZEGU99" from "ZEGU99 - G7 Maintenance 2026")

## Files
src/app/cases/page.tsx

## Deploy
```bash
cd /workspaces/aroet
# Upload aroet-fix7b.zip
cd /tmp && rm -rf fix7b && unzip -o /workspaces/aroet/aroet-fix7b.zip -d fix7b
cd /workspaces/aroet
cp -r /tmp/fix7b/src/* src/
rm -rf /tmp/fix7b
git add -A && git commit -m "Fix 7B: remove project_code column reference" && git push
```
