# AROET Fix 4 — Workforce calendar shows 0 sessions (schema mismatch)

## Problem
- Workforce calendar at /workforce displayed "No sessions in this period" despite 1566 sessions in DB.
- Root cause: workforce/page.tsx queried column names that don't exist in schema:
  • engineers.name  → actually `full_name`
  • cases.service_type → actually `service_type_name`
  • cases.customer_code → actually `customer_name`
- Supabase returned null silently → page treated as "no data"

## Fix
- Map full_name → name on the server before passing to client
- Map service_type_name/customer_name → service_type/customer_code for client
- Also: changed Session.id from `number` → `string` (it's uuid)
- All approval action sessionId params: `number` → `string`

## Files changed
src/app/workforce/page.tsx
src/app/workforce/calendar.tsx
src/app/workforce/actions.ts

## Deploy
```bash
cd /workspaces/aroet
# Upload aroet-fix4.zip into workspace
cd /tmp && rm -rf fix4 && unzip -o /workspaces/aroet/aroet-fix4.zip -d fix4
cd /workspaces/aroet
cp -r /tmp/fix4/src/* src/
rm -rf /tmp/fix4
git add -A
git commit -m "Fix 4: workforce schema mismatch (full_name, service_type_name)"
git push
```

## Expected
- /workforce shows engineers with sessions
- Heat bar visible
- Click ▸ to expand engineer → see SO breakdown
