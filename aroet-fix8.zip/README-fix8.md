# AROET Sprint 2 — New Case Workflow

## What's in this drop
Complete rewrite of `/cases/new` with:
- SO + SR number (both required)
- Customer search + create new inline
- Multi-machine selector with ⭐ primary toggle
- Project code Suggest button (uses project_mapping table)
- Service type dropdown (Curative/PM/Installation/SA/Training/Upgrade)
- Description textarea
- Lead engineer (required) + other engineers (multi)
- Due date
- Optional planner_note (auto-parse on save)

## Files
sql/05_new_case_workflow.sql                   ← run in Supabase first
src/app/cases/new/page.tsx                     (loads customers, engineers, machines)
src/app/cases/new/form.tsx                     (UI)
src/app/cases/new/actions.ts                   (server actions)

## Database changes
- `cases.sr_number text` (D365 case ID)
- `cases.project_code text`
- `cases.description text`
- `case_machines` junction table (so_number, machine_no, is_primary)
- `project_mapping` lookup table (~13 seeded mappings, can grow over time)

## Deploy

### 1. Run SQL migration in Supabase
Paste contents of `sql/05_new_case_workflow.sql` into Supabase SQL Editor → Run.

You should see in verify section:
- `project_mappings_seeded`: 13 (or more if you re-run)
- `has_sr_number`: sr_number
- `has_project_code`: project_code

### 2. Apply code
```bash
cd /workspaces/aroet
# Upload aroet-fix8.zip to workspace
cd /tmp && rm -rf fix8
unzip -o /workspaces/aroet/aroet-fix8.zip -d fix8

cd /workspaces/aroet
cp -r /tmp/fix8/src/* src/
cp /tmp/fix8/sql/05_new_case_workflow.sql sql/
rm -rf /tmp/fix8

git add -A
git commit -m "Sprint 2: New case workflow with SR+project+multi-machine"
git push
```

## Test flow (after deploy)

1. Go to `/cases/new`
2. Fill SO: `SO2605-99` (test)
3. Fill SR: `SR26-AROET99999`
4. Search customer "Essilor" → if exists pick it, else click "+ Add new customer"
5. Type machine "MCVP4-99" → "+ Add new machine"
6. Click 🪄 Suggest on Project code → see suggestions
7. Pick service type, fill description
8. Pick lead engineer (e.g., JKH)
9. (Optional) paste planner note
10. Click Create case
11. Should redirect to `/cases/SO2605-99`

## How "Suggest" works
The `project_mapping` table holds rules like:
- machine_prefix="MCVP4" + customer_pattern="LUXOTTICA" → "ZEGU99" (confidence 80)
- machine_prefix="PE9" + customer_pattern="ESSILOR LAO" → "ESSA01" (confidence 85)

When you click Suggest, the action:
1. Extracts machine prefix from each selected machine
2. Gets the customer name
3. Scores each mapping by prefix match + customer match
4. Returns top 5 candidates with confidence %

You can edit the table later to teach it more patterns:
```sql
INSERT INTO project_mapping (machine_prefix, customer_pattern, project_code, confidence)
VALUES ('YOUR_PREFIX', 'YOUR_CUSTOMER', 'YOUR_PROJECT', 80);
```

## Notes
- Customer "code" auto-generates from name if blank
- Machine inline-create requires customer selected first
- All Sprint 1 design tokens applied (rounded-2xl, 14px body, etc.)
- Primary machine = first added by default, click to switch
- Title is auto-built: `{project_code} - {machine list} - {description first line}`
