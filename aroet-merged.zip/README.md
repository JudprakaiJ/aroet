# AROET — Combined Deploy (Fix 11 → Fix 14)

This zip merges everything from Sprint 5 → Fix 14 into one deploy.
It catches up your /workspaces/aroet to the current state in chat.

## What's included

### Sprint 5 (Fix 11) — Cleanup
- Removed Planner Note section from /cases/new
- Title field added (started as required, now relaxed)
- SO/SR format validation

### Fix 12 — Dashboard polish
- Dashboard "All N cases" (queries DB instead of hardcoded 883)
- Dashboard "Create case · SO + customer + machines" (was "From planner note")
- /cases removed "⚡ Bulk parse" button

### Fix 13 — Title-paste section
- ✨ Paste D365 title section at top of /cases/new
- Initial regex parser (later replaced by Fix 13B)

### Fix 13B — Smart parser + Optional fields
- Server-side `parseTitleSmart()` with DB lookup
- Queries machines + cases.project_code to disambiguate
- Auto-adds matched machine to selection on Auto-fill
- "✓ DB" badge for verified codes
- "Found in title but not in DB" hints
- Only SO + Customer required; everything else optional
- Service Types: 9 correct D365 codes (7505, 7504, 7515, 7508, 7507, 7512, 7235, 7506, 7506-1)

### Fix 14 — Merged Workforce nav
- Top nav reduced: Dashboard / Cases / Workforce / Customers / Machines / Team
- /workforce has 3 tabs: 📋 Plan / ⏱️ Hours / ✅ Queue
- Pending count badge on Queue tab (red)
- /planning and /workforce/queue still work — auto-redirect to new tab URLs
- Dashboard "Pending approval" links to /workforce?tab=queue

## SQL required
Run BOTH SQL files (idempotent — safe to re-run):

### 07_planning_type_code.sql
Adds `sessions.type_code` column for planning grid types (T/V/A/PERS/AL/SICK/WFH/OFF).

### 08_sessions_nullable_so.sql
Makes `sessions.so_number` nullable so leave types (AL/SICK/PERS) can be saved without a case.

## Deploy

```bash
cd /workspaces/aroet
# Upload aroet-merged.zip
cd /tmp && rm -rf merged
unzip -o /workspaces/aroet/aroet-merged.zip -d merged

cd /workspaces/aroet
cp -r /tmp/merged/src/* src/
cp /tmp/merged/sql/*.sql sql/
rm -rf /tmp/merged

# Cleanup stale files (if they ever existed)
rm -f src/lib/title-parser.ts
rm -f src/app/planning/client.tsx

git add -A
git commit -m "Merged: Fix 11-14 — cleanup, parser, Workforce tabs"
git push
```

Then run SQL in Supabase SQL Editor:
1. Paste contents of `sql/07_planning_type_code.sql` → Run
2. Paste contents of `sql/08_sessions_nullable_so.sql` → Run

## Verify after deploy

1. Top nav shows 6 links: Dashboard | Cases | Workforce | Customers | Machines | Team
2. Dashboard:
   - "Create case · SO + customer + machines"
   - "Browse cases · All N cases" (N = real count)
   - "Pending approval" → /workforce?tab=queue
3. /cases — no "⚡ Bulk parse" button
4. /cases/new:
   - ✨ Paste D365 title section at top
   - Service Type dropdown has 9 D365 codes
   - Only SO Number + Customer are required
5. /workforce — 3 tabs (Plan/Hours/Queue) with red badge on Queue
6. Old URLs redirect:
   - /planning → /workforce?tab=plan
   - /workforce/queue → /workforce?tab=queue
