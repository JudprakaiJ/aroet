"use client";

import { useState, useTransition, useMemo, Fragment } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { assignSession, updatePlanningSession, clearDay, deletePlanningSession } from "./actions";

interface Engineer {
  code: string;
  full_name: string;
  role: string;
  is_active: boolean;
}

interface Session {
  id: number;
  engineer_code: string;
  session_date: string;
  so_number?: string | null;
  machine_no?: string | null;
  type_code?: string | null;
  activity_type?: string | null;
  travel_minutes: number;
  work_minutes: number;
  office_minutes: number;
  work_done?: string | null;
  approval_status: string;
}

interface Case {
  so_number: string;
  customer_name?: string | null;
  project_code?: string | null;
  service_type_code?: string | null;
  title?: string | null;
  machine_no?: string | null;
}

// Type code styles
const TYPE_STYLES: Record<string, { bg: string; fg: string; chip: string; border: string; label: string }> = {
  T:    { bg: "#C0DD97", fg: "#173404", chip: "rgba(23,52,4,0.15)",  border: "#97C459", label: "In-country" },
  V:    { bg: "#639922", fg: "#FFFFFF", chip: "rgba(255,255,255,0.2)", border: "#3B6D11", label: "Overseas" },
  A:    { bg: "#D3D1C7", fg: "#2C2C2A", chip: "rgba(255,255,255,0.4)", border: "#B4B2A9", label: "TBD" },
  PERS: { bg: "#85B7EB", fg: "#042C53", chip: "rgba(255,255,255,0.4)", border: "#5C9BD6", label: "Personal" },
  AL:   { bg: "#AFA9EC", fg: "#26215C", chip: "rgba(255,255,255,0.4)", border: "#7F77DD", label: "Annual Leave" },
  SICK: { bg: "#444441", fg: "#FFFFFF", chip: "rgba(255,255,255,0.2)", border: "#2C2C2A", label: "Sick" },
  WFH:  { bg: "#E5DBA3", fg: "#6B3D04", chip: "rgba(255,255,255,0.4)", border: "#BA7517", label: "Work from home" },
  OFF:  { bg: "#F1EFE8", fg: "#2C2C2A", chip: "rgba(0,0,0,0.08)",       border: "#D3D1C7", label: "Office" },
};

const WORK_TYPES = ["T", "V", "A"];
const LEAVE_TYPES = ["AL", "SICK", "PERS", "WFH", "OFF"];

export default function PlanningClient({
  engineers,
  sessions,
  cases,
  startDate,
  endDate,
  weeks,
}: {
  engineers: Engineer[];
  sessions: Session[];
  cases: Case[];
  startDate: string;
  endDate: string;
  weeks: number;
}) {
  const router = useRouter();
  const [modalCell, setModalCell] = useState<{
    engineer_code: string;
    session_date: string;
    existing?: Session;
  } | null>(null);

  // Build days array
  const days = useMemo(() => {
    const result: { date: string; day: number; weekday: string; isWeekend: boolean; isMonday: boolean }[] = [];
    const start = new Date(startDate);
    const end = new Date(endDate);
    const cur = new Date(start);
    while (cur <= end) {
      const wd = cur.getDay();
      result.push({
        date: cur.toISOString().split("T")[0],
        day: cur.getDate(),
        weekday: ["S", "M", "T", "W", "T", "F", "S"][wd],
        isWeekend: wd === 0 || wd === 6,
        isMonday: wd === 1,
      });
      cur.setDate(cur.getDate() + 1);
    }
    return result;
  }, [startDate, endDate]);

  // Build session map: key = `${engineer}-${date}`
  const sessionMap = useMemo(() => {
    const m = new Map<string, Session[]>();
    sessions.forEach((s) => {
      const key = `${s.engineer_code}-${s.session_date}`;
      if (!m.has(key)) m.set(key, []);
      m.get(key)!.push(s);
    });
    return m;
  }, [sessions]);

  // Build case map
  const caseMap = useMemo(() => {
    const m = new Map<string, Case>();
    cases.forEach((c) => m.set(c.so_number, c));
    return m;
  }, [cases]);

  function navigatePeriod(deltaWeeks: number) {
    const newStart = new Date(startDate);
    newStart.setDate(newStart.getDate() + deltaWeeks * 7);
    router.push(`/planning?weeks=${weeks}&start=${newStart.toISOString().split("T")[0]}`);
  }

  return (
    <div className="max-w-full px-6 py-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
        <div>
          <h1 className="text-[22px] font-bold leading-tight">Planning</h1>
          <p className="text-[12px] text-slate-500 mt-0.5">
            {fmtDateRange(startDate, endDate)} · {weeks} weeks · {engineers.length} engineers
          </p>
        </div>
        <div className="flex gap-1.5 items-center">
          <button
            onClick={() => navigatePeriod(-Math.floor(weeks / 2))}
            className="text-[11px] px-2 py-1 rounded border border-slate-300 bg-white hover:bg-slate-50"
          >
            ◀
          </button>
          <select
            value={weeks}
            onChange={(e) => router.push(`/planning?weeks=${e.target.value}&start=${startDate}`)}
            className="text-[11px] px-2 py-1 rounded border border-slate-300 bg-white"
          >
            <option value="4">4 weeks</option>
            <option value="8">8 weeks</option>
            <option value="12">12 weeks (3mo)</option>
          </select>
          <button
            onClick={() => navigatePeriod(Math.floor(weeks / 2))}
            className="text-[11px] px-2 py-1 rounded border border-slate-300 bg-white hover:bg-slate-50"
          >
            ▶
          </button>
        </div>
      </div>

      {/* Legend */}
      <div className="flex gap-2 flex-wrap mb-3 text-[10px] items-center">
        <span className="text-slate-500 font-medium mr-1">Type:</span>
        {Object.entries(TYPE_STYLES).map(([code, st]) => (
          <span
            key={code}
            className="px-2 py-0.5 rounded font-bold"
            style={{ background: st.bg, color: st.fg }}
            title={st.label}
          >
            {code}
          </span>
        ))}
        <span
          className="px-2 py-0.5 rounded font-bold"
          style={{ background: "#F09595", color: "#501313" }}
        >
          Wknd
        </span>
      </div>

      {/* Grid */}
      <div className="bg-white border border-slate-200 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="border-collapse text-[9px]" style={{ tableLayout: "fixed", minWidth: "100%" }}>
            <thead>
              <tr style={{ background: "#F8FAFC", borderBottom: "1.5px solid #1a1a1a" }}>
                <th
                  className="sticky left-0 z-10 text-center font-semibold text-[10px]"
                  style={{
                    background: "#F8FAFC",
                    width: 50,
                    padding: "4px 6px",
                    borderRight: "1.5px solid #1a1a1a",
                  }}
                >
                  Eng
                </th>
                {days.map((d) => (
                  <th
                    key={d.date}
                    style={{
                      background: d.isWeekend ? "#F09595" : "#C0DD97",
                      color: d.isWeekend ? "#501313" : "#173404",
                      padding: "3px 1px",
                      fontWeight: 500,
                      fontSize: 9,
                      width: 42,
                      borderRight: d.isMonday ? "2px solid #1a1a1a" : "0.5px solid #B5D4F4",
                    }}
                  >
                    <div>{d.day}</div>
                    <div style={{ fontSize: 8, opacity: 0.65 }}>{d.weekday}</div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {engineers.map((eng) => (
                <tr key={eng.code}>
                  <td
                    className="sticky left-0 z-10 text-center font-bold text-[11px]"
                    style={{
                      background: "#FFFFFF",
                      padding: "2px 4px",
                      borderRight: "1.5px solid #1a1a1a",
                      borderBottom: "0.5px solid #E2E8F0",
                    }}
                  >
                    {eng.code}
                  </td>
                  {days.map((d) => {
                    const key = `${eng.code}-${d.date}`;
                    const cellSessions = sessionMap.get(key) ?? [];
                    return (
                      <td
                        key={d.date}
                        onClick={() =>
                          setModalCell({
                            engineer_code: eng.code,
                            session_date: d.date,
                            existing: cellSessions[0],
                          })
                        }
                        style={{
                          background: d.isWeekend ? "#F09595" : "#FFFFFF",
                          borderRight: d.isMonday ? "2px solid #1a1a1a" : "0.5px solid #E2E8F0",
                          borderBottom: "0.5px solid #E2E8F0",
                          padding: 0,
                          cursor: d.isWeekend ? "default" : "pointer",
                          verticalAlign: "top",
                          height: 60,
                        }}
                      >
                        {!d.isWeekend && cellSessions.length > 0 && (
                          <PlanningCell session={cellSessions[0]} caseInfo={caseMap.get(cellSessions[0].so_number || "")} />
                        )}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <p className="text-[11px] text-slate-400 italic mt-3 text-center">
        Click cell → assign or edit · Scroll horizontally for more weeks
      </p>

      {/* Assign modal */}
      {modalCell && (
        <AssignModal
          engineer_code={modalCell.engineer_code}
          session_date={modalCell.session_date}
          existing={modalCell.existing}
          cases={cases}
          onClose={() => setModalCell(null)}
          onSuccess={() => {
            setModalCell(null);
            router.refresh();
          }}
        />
      )}
    </div>
  );
}

function PlanningCell({ session, caseInfo }: { session: Session; caseInfo?: Case }) {
  const type = (session.type_code || "T").toUpperCase();
  const style = TYPE_STYLES[type] || TYPE_STYLES.T;
  const isLeave = LEAVE_TYPES.includes(type);
  const serviceCode = caseInfo?.service_type_code || "";

  // Leave/TBD = center big letter
  if (isLeave && !session.so_number) {
    return (
      <div
        style={{
          background: style.bg,
          color: style.fg,
          width: "100%",
          height: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: type.length > 2 ? 11 : 13,
          fontWeight: 700,
          lineHeight: 1,
        }}
      >
        {type}
      </div>
    );
  }

  // Work cell: 3 lines + chip
  return (
    <div
      style={{
        background: style.bg,
        color: style.fg,
        width: "100%",
        height: "100%",
        padding: 3,
        lineHeight: 1.15,
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
      }}
    >
      <div>
        {caseInfo?.project_code && (
          <div style={{ fontSize: 10, fontWeight: 700 }}>{caseInfo.project_code}</div>
        )}
        {session.so_number && <div style={{ fontSize: 8 }}>{session.so_number}</div>}
        {session.machine_no && (
          <div style={{ fontSize: 8, opacity: 0.85 }}>{session.machine_no}</div>
        )}
      </div>
      <div
        style={{
          alignSelf: "flex-start",
          background: style.chip,
          padding: "0 4px",
          borderRadius: 2,
          fontSize: 9,
          fontWeight: 700,
          marginTop: 1,
        }}
      >
        {type}
        {serviceCode && ` · ${serviceCode}`}
      </div>
    </div>
  );
}

function AssignModal({
  engineer_code,
  session_date,
  existing,
  cases,
  onClose,
  onSuccess,
}: {
  engineer_code: string;
  session_date: string;
  existing?: Session;
  cases: Case[];
  onClose: () => void;
  onSuccess: () => void;
}) {
  const [pending, startTransition] = useTransition();
  const [type, setType] = useState(existing?.type_code || "T");
  const [soNumber, setSoNumber] = useState(existing?.so_number || "");
  const [notes, setNotes] = useState(existing?.work_done || "");
  const [error, setError] = useState("");
  const [caseSearch, setCaseSearch] = useState("");
  const [showCaseList, setShowCaseList] = useState(false);

  const isWork = WORK_TYPES.includes(type);
  const selectedCase = cases.find((c) => c.so_number === soNumber);
  const filteredCases = caseSearch
    ? cases.filter(
        (c) =>
          c.so_number.toLowerCase().includes(caseSearch.toLowerCase()) ||
          (c.title || "").toLowerCase().includes(caseSearch.toLowerCase()) ||
          (c.project_code || "").toLowerCase().includes(caseSearch.toLowerCase())
      )
    : cases;

  function handleSave() {
    setError("");
    startTransition(async () => {
      const result = existing
        ? await updatePlanningSession(existing.id, {
            type_code: type,
            so_number: isWork ? soNumber : null,
            notes,
          })
        : await assignSession({
            engineer_code,
            session_date,
            type_code: type,
            so_number: isWork ? soNumber : null,
            notes,
          });
      if (result.success) onSuccess();
      else setError(result.error || "Failed");
    });
  }

  function handleDelete() {
    if (!existing) return;
    if (!confirm("Delete this session?")) return;
    setError("");
    startTransition(async () => {
      const result = await deletePlanningSession(existing.id);
      if (result.success) onSuccess();
      else setError(result.error || "Failed");
    });
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: "rgba(15,23,42,0.5)" }}
    >
      <div className="bg-white rounded-2xl p-5 max-w-md w-full shadow-xl max-h-[90vh] overflow-auto">
        <div className="flex items-center justify-between mb-3 pb-3 border-b border-slate-100">
          <div>
            <h3 className="text-[16px] font-semibold">
              {existing ? "Edit assignment" : "Assign session"}
            </h3>
            <p className="text-[12px] text-slate-500">
              {engineer_code} · {fmtDateLong(session_date)}
            </p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 text-lg">
            ✕
          </button>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-2 mb-3 text-[12px] text-red-700">
            ⚠ {error}
          </div>
        )}

        <div className="mb-3">
          <label className="block text-[12px] font-medium text-slate-700 mb-1.5">
            Type <span style={{ color: "#C8102E" }}>*</span>
          </label>
          <div className="grid grid-cols-4 gap-1.5">
            {Object.entries(TYPE_STYLES).map(([code, st]) => {
              const isActive = type === code;
              return (
                <button
                  key={code}
                  type="button"
                  onClick={() => setType(code)}
                  className="text-[11px] py-2 rounded font-bold transition-all"
                  style={{
                    background: isActive ? st.bg : "#FFFFFF",
                    color: isActive ? st.fg : "#1a1a1a",
                    border: isActive ? `1.5px solid ${st.border}` : "1px solid #e2e8f0",
                  }}
                  title={st.label}
                >
                  {code}
                </button>
              );
            })}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">{TYPE_STYLES[type]?.label}</p>
        </div>

        {isWork && (
          <div className="mb-3">
            <label className="block text-[12px] font-medium text-slate-700 mb-1.5">
              Case (SO) <span style={{ color: "#C8102E" }}>*</span>
            </label>
            {selectedCase ? (
              <div className="flex items-center justify-between p-2 border border-slate-200 rounded-lg bg-slate-50">
                <div className="text-[12px] min-w-0">
                  <div className="font-mono font-semibold">{selectedCase.so_number}</div>
                  <div className="text-slate-500 truncate">
                    {selectedCase.project_code && `${selectedCase.project_code} · `}
                    {selectedCase.title || selectedCase.customer_name}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setSoNumber("");
                    setCaseSearch("");
                  }}
                  className="text-[11px] text-slate-500 hover:text-slate-700 ml-2 flex-shrink-0"
                >
                  Change
                </button>
              </div>
            ) : (
              <div className="relative">
                <input
                  value={caseSearch}
                  onChange={(e) => {
                    setCaseSearch(e.target.value);
                    setShowCaseList(true);
                  }}
                  onFocus={() => setShowCaseList(true)}
                  placeholder="Search SO, title, project..."
                  className="w-full px-3 py-2 text-[13px] border border-slate-200 rounded-lg"
                />
                {showCaseList && (
                  <div className="absolute z-20 left-0 right-0 mt-1 bg-white border border-slate-200 rounded-lg shadow-md max-h-48 overflow-auto">
                    {filteredCases.slice(0, 10).map((c) => (
                      <div
                        key={c.so_number}
                        onClick={() => {
                          setSoNumber(c.so_number);
                          setShowCaseList(false);
                          setCaseSearch("");
                        }}
                        className="px-3 py-2 hover:bg-slate-50 cursor-pointer border-b border-slate-100 last:border-0 text-[12px]"
                      >
                        <div className="font-mono font-semibold">{c.so_number}</div>
                        <div className="text-slate-500 truncate">
                          {c.project_code && `${c.project_code} · `}
                          {c.title || c.customer_name}
                        </div>
                      </div>
                    ))}
                    {filteredCases.length === 0 && (
                      <div className="px-3 py-2 text-[12px] text-slate-400 italic">
                        No cases found
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        <div className="mb-3">
          <label className="block text-[12px] font-medium text-slate-700 mb-1.5">Notes</label>
          <textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Optional notes"
            rows={2}
            className="w-full px-3 py-2 text-[13px] border border-slate-200 rounded-lg"
          />
        </div>

        <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-100">
          {existing && (
            <button
              type="button"
              onClick={handleDelete}
              disabled={pending}
              className="text-[12px] px-3 py-1.5 rounded font-medium"
              style={{ color: "#C8102E" }}
            >
              🗑 Delete
            </button>
          )}
          <div className="flex gap-2 ml-auto">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-[13px] border border-slate-300 bg-white"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSave}
              disabled={pending || (isWork && !soNumber)}
              className="px-5 py-2 rounded-lg text-[13px] text-white disabled:opacity-50"
              style={{ background: "#C8102E" }}
            >
              {pending ? "Saving..." : "✓ Save"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function fmtDateRange(start: string, end: string): string {
  const s = new Date(start);
  const e = new Date(end);
  const monthShort = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  return `${s.getDate()} ${monthShort[s.getMonth()]} – ${e.getDate()} ${monthShort[e.getMonth()]} ${e.getFullYear()}`;
}

function fmtDateLong(d: string): string {
  const date = new Date(d);
  const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  return `${days[date.getDay()]} ${date.getDate()} ${months[date.getMonth()]} ${date.getFullYear()}`;
}
