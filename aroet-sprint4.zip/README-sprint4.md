# AROET Sprint 4 — Planning Grid (Excel-style)

## What's new

### /planning — REWRITTEN as grid
- **Layout**: Engineers in rows (PSU/JKH/...) × Dates in columns
- **Default**: 8 weeks (2 months), starting from this Monday
- **Range selector**: 4 / 8 / 12 weeks
- **Navigation**: ◀ Prev / Next ▶ buttons by chunk
- **Cell content** (Option B Compact):
  - Project code (e.g. ESTH98)
  - SO number
  - Machine
  - Type · Service chip (bottom) — e.g. "T · 7507"
- **Leave cells** (AL/SICK/PERS/WFH/OFF):
  - Centered big letter — no info clutter
- **Visual**:
  - Weekend = red background, 2px black line after Sunday
  - Week separator = thick black border
  - Engineer column = sticky left, code only (PSU/JKH/etc.)
  - Cell ≈ 62×62px

### Click cell → Assign modal
- Type buttons (T/V/A/PERS/AL/SICK/WFH/OFF) with labels
- Case (SO) dropdown — required for work types
- Notes (optional)
- Save / Clear day buttons

### Type code mapping (sessions.type_code)
| Code | Means | Minutes |
|------|-------|---------|
| T | In-country confirmed | 8h work |
| V | Overseas confirmed | 8h work |
| A | TBD | 8h work |
| PERS | Personal | 0 |
| AL | Annual leave | 0 |
| SICK | Sick | 0 |
| WFH | Work from home | 8h work |
| OFF | Office | 8h office |

## Schema changes
**sql/07_planning_type_code.sql**:
- `sessions.type_code text` (new column)
- Index on type_code + (engineer_code, session_date)
- Backfill: maps existing activity_type → type_code

## Files
sql/07_planning_type_code.sql       Run in Supabase first
src/app/planning/page.tsx           NEW (server)
src/app/planning/grid.tsx           NEW (client grid + modal)
src/app/planning/actions.ts         NEW (assignSession, deleteSessionFromGrid)

## Deploy

### 1. Run SQL in Supabase
Paste `sql/07_planning_type_code.sql` → Run. Verify section should show:
- sessions_with_type_code = (your session count)
- sessions_missing_type_code = 0

### 2. Apply code
```bash
cd /workspaces/aroet
# Upload aroet-sprint4.zip
cd /tmp && rm -rf sprint4
unzip -o /workspaces/aroet/aroet-sprint4.zip -d sprint4

cd /workspaces/aroet
cp -r /tmp/sprint4/src/* src/
cp /tmp/sprint4/sql/07_planning_type_code.sql sql/
rm -rf /tmp/sprint4

# Remove any stale planning/client.tsx that may exist
rm -f src/app/planning/client.tsx

git add -A
git commit -m "Sprint 4: Planning Grid (Excel-style 5-line cells with type_code)"
git push
```

## Test flow
1. Go to `/planning`
2. See grid with all active engineers × dates
3. Click empty cell → Assign modal
4. Select type "T", pick a case, save
5. Cell now shows: Project / SO / Machine / "T · 7507" chip
6. Try "AL" — cell shows centered "AL"
7. Use ◀ ▶ buttons to navigate weeks
8. Change to 12 weeks (3 mo) view

## Known limitations
- ⚠ Currently assigning AL/SICK/PERS without an SO may fail if your DB has `sessions.so_number NOT NULL` constraint. To fix:
  ```sql
  alter table sessions alter column so_number drop not null;
  ```
  Or assign leave types to an "admin/leave" case for now.
- Hover tooltip shows basic case info — could be enhanced
- No drag & drop yet (only click-to-edit)
- No filter by engineer (all active shown)

## Future enhancements (Sprint 5+)
- Drag session between cells
- Filter engineers
- Right-click context menu (copy, paste, repeat)
- Multi-day select (assign across range)
- Conflict detection (overlapping assignments)
