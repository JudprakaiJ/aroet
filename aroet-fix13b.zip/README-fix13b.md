# AROET Fix 13B — Smart Parser + Optional Fields

## What's new

### 1. Smart title parser with DB lookup (server-side)
- Old parser: pure regex (couldn't tell Project vs Machine apart)
- New parser: `parseTitleSmart()` server action
  - Extracts candidates with regex
  - **Queries machines table** → tags as Machine
  - **Queries cases.project_code** → tags as Project
  - Strips noise: 10-digit PO, ELN/LN26-xxxx, (SQxxx-xx), CSxxxxx
  - Returns: SO + Project + Machine + Subject + unmatched_codes (hints)

### 2. Auto-add matched machine
When parser finds machine in DB → auto-added to selected machines on Auto-fill (no need to search again)

### 3. UI improvements
- "✓ DB" badge next to Project/Machine when verified from database
- "Parsing..." indicator during DB lookup
- "Found in title but not in DB: ..." hint for unmatched codes
- Updated placeholder to show MITSF27/ESTH48 example

### 4. Field requirements relaxed
Only **SO Number + Customer** are required now.

Previously required (now optional):
- SR Number — optional (format check only if provided)
- Title — optional (auto-defaults to `{project} {SO}` if blank)
- Description — optional
- Machines — optional (0+ allowed, add later)
- Lead engineer — optional ("— Not assigned yet —" default)
- Service type — defaults to "Curative 7505" if not set

### 5. createCase server action updated
Tolerates missing fields:
- `sr_number` → null if blank
- `title` → null if blank
- `machine_nos` → empty array allowed (skip case_machines insert)
- `lead_engineer` → null/empty allowed (skip case_engineers insert)
- `service_type_code` → defaults to "7505"

## Test (verified with your 6 examples)

| Title | Project | Machine (DB) |
|-------|---------|--------------|
| SO2604-05 - ESRY13 - Line#15 - Installation... | ESRY13 ✓ | (Line#15 unmatched) |
| SO2603-27 - MITSF27 - ESTH48 - Installation of New PC... | ESTH48 ✓ | MITSF27 ✓ |
| SO2605-01 CS29459 - RE55 - ESSA05 - request support... | ESSA05 ✓ | RE55 ✓ |
| SO2603-26 - AR25SV484 - ESFOC98 - SPV3... | ESFOC98 ✓ | (AR25SV484 if in DB) |
| SO2602-19 - Group 1 - ROTH99 - PM 2026 | ROTH99 ✓ | (Group 1 unmatched) |
| SO2602-08 - RE72 - ESSA01 - TLS issue | ESSA01 ✓ | RE72 ✓ |

DB lookup matches against:
- `machines.machine_no` for Machine field
- `cases.project_code` (distinct) for Project field

## Files
src/app/cases/new/form.tsx              (use parseTitleSmart, relaxed validation, optional field labels)
src/app/cases/new/actions.ts            (NEW: parseTitleSmart server action; createCase tolerates missing fields)

## Deploy (no SQL)

```bash
cd /workspaces/aroet
# Upload aroet-fix13b.zip
cd /tmp && rm -rf fix13b
unzip -o /workspaces/aroet/aroet-fix13b.zip -d fix13b

cd /workspaces/aroet
cp -r /tmp/fix13b/src/* src/
rm -rf /tmp/fix13b

# If previous Fix 13 left a stale file:
rm -f src/lib/title-parser.ts

git add -A
git commit -m "Fix 13B: smart parser DB lookup + optional fields"
git push
```

## Test flow

1. /cases/new
2. Paste: `SO2603-27 - MITSF27 - ESTH48 - Installation of the New PC - LN26-0979-0 (SQ2602-44)`
3. Wait 500ms (DB lookup roundtrip)
4. "Detected" panel shows:
   - SO Number: SO2603-27
   - Project: ESTH48 ✓ DB
   - Machine: MITSF27 ✓ DB
   - Title: Installation of the New PC
5. Click "↓ Auto-fill empty fields"
6. SO + Project + Title populated
7. **MITSF27 added to Machines section automatically** ✓
8. Form now allows: SO + Customer only → Create case button works
   (SR/Lead/etc. can be added later)

## Known limitations

- DB lookup is empty when no machines/cases exist yet (fresh DB)
  → Build up your machines table first via /machines or bulk import
- If your machine list is huge (1000+), queries are still fast (indexed lookups)
- Parser cannot distinguish 2 codes where both could be project or machine (DB ambiguity)
